const express = require("express");
const router = express.Router();
const Contact = require("../models/contact");

// POST: Save contact form data
router.post("/", async (req, res) => {
    try {
        const { name, email, mobile, message } = req.body;

        if (!name || !email || !mobile || !message) {
            return res.status(400).json({ message: "All fields are required!" });
        }

        const newContact = new Contact({ name, email, mobile, message });
        await newContact.save();

        res.status(201).json({ message: "Contact request submitted successfully!" });
    } catch (error) {
        console.error("Error saving contact:", error);
        res.status(500).json({ message: "Internal Server Error" });
    }
});

// GET: Fetch all contact requests
router.get("/", async (req, res) => {
    try {
        const contacts = await Contact.find().sort({ date: -1 });
        res.status(200).json(contacts);
    } catch (error) {
        console.error("Error fetching contacts:", error);
        res.status(500).json({ message: "Internal Server Error" });
    }
});
// Delete Contact Route
router.delete("/:id", async (req, res) => {
    try {
        await Contact.findByIdAndDelete(req.params.id);
        res.status(200).json({ message: "Contact deleted successfully" });
    } catch (error) {
        res.status(500).json({ error: "Failed to delete contact" });
    }
});

// Mark Contact as Complete
// Mark Contact as Completed
router.put("/:id/complete", async (req, res) => {
    try {
        const contact = await Contact.findByIdAndUpdate(req.params.id, { status: "Completed" }, { new: true });
        if (!contact) {
            return res.status(404).json({ message: "Contact not found" });
        }
        res.json(contact);
    } catch (error) {
        res.status(500).json({ message: "Server Error", error });
    }
});


module.exports = router;
