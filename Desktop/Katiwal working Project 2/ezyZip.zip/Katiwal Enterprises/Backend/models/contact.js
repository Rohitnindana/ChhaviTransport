const mongoose = require("mongoose");

const contactSchema = new mongoose.Schema({
    name: String,
    email: String,
    mobile: String,
    message: String,
    date: { type: Date, default: Date.now },
    status: { type: String, default: "Pending" } // ✅ Added Status Field
});

module.exports = mongoose.model("Contact", contactSchema);
