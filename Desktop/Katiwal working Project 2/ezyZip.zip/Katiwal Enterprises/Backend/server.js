const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");
require("dotenv").config();

const app = express();
app.use(express.json());
app.use(cors());

// Serve static files from 'Public' and 'Views' folders
app.use(express.static(path.join(__dirname, "../Frontend/Public")));
app.use(express.static(path.join(__dirname, "../Frontend/Views")));

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, { 
    useNewUrlParser: true, 
    useUnifiedTopology: true 
})
.then(() => console.log("Connected to MongoDB Atlas"))
.catch(err => console.error("MongoDB connection error:", err));

// Import routes
const contactRoutes = require("./routes/contact");
app.use("/api/contacts", contactRoutes);

// Serve frontend pages
const pages = ["index", "login", "dashboard", "about", "services", "contact"];
pages.forEach(page => {
    app.get(`/${page}`, (req, res) => {
        res.sendFile(path.join(__dirname, `../Frontend/Views/${page}.html`));
    });
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
