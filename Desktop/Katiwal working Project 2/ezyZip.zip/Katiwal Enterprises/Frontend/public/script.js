document.getElementById("contactForm").addEventListener("submit", async function(event) {
    event.preventDefault();

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const mobile = document.getElementById("mobile").value;
    const message = document.getElementById("message").value;

    const requestBody = { name, email, mobile, message };

    try {
        const response = await fetch("http://localhost:5000/api/contacts", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(requestBody)
        });

        if (response.ok) {
            alert("Contact form submitted successfully!");
            document.getElementById("contactForm").reset();
        } else {
            alert("Failed to submit form. Please try again.");
        }
    } catch (error) {
        console.error("Error submitting form:", error);
    }
});